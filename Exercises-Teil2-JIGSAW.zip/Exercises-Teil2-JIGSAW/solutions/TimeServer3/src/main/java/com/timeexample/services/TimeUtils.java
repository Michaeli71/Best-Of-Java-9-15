package com.timeexample.services;

import java.time.LocalDateTime;
import java.util.logging.Logger;

public class TimeUtils 
{
	public static LocalDateTime getCurrentTime()
	{
		Logger.getGlobal().info("getCurrentTime() is called()");
		return LocalDateTime.now();
	} 
}
