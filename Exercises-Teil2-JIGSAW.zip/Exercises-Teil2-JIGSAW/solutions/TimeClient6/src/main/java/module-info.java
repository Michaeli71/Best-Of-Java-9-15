module timeclient {
	requires timeservice;
	requires com.google.common;
	
	//requires guava;
	
	uses com.timeexample.spi.TimeService;
}