package exercises.part4_5.java12_13_14;

import java.util.List;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise2_CompactNumberFormat 
{
	public static void main(final String args[]) 
	{
		List<Integer> allValues = List.of(1_000, 1_000_000, 1_000_000_000);
		List<String> germanParseInputs = List.of("13 KILO", "1 Mio.", "1 Mrd.");
		List<String> italianParseInputs = List.of("1 mille", "1 milione");
		
		// TODO		
	}
}
