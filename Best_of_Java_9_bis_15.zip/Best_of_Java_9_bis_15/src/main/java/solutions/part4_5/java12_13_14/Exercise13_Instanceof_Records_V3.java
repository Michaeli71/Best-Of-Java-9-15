package solutions.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise13_Instanceof_Records_V3 
{
	// Verbesserung durch Anwenden von Polymorphie und Nutzen des Basistyps in der Signatur
	public double computeArea(final BaseFigure figure) 
	{
		return figure.calcArea();
	}
	
	
	interface BaseFigure
	{
		double calcArea();
	}
	
	record Square(double sideLength) implements BaseFigure {

		@Override
		public double calcArea() {
			return sideLength * sideLength;
		}
	}

	record Circle(double radius) implements BaseFigure 
	{
		@Override
		public double calcArea() 
		{
			return radius * radius * Math.PI;
		}
	}

	// Rectangle
	record Rectangle(double width, double height) implements BaseFigure {

		@Override
		public double calcArea() {
			return width * height;
		}
	}
}
