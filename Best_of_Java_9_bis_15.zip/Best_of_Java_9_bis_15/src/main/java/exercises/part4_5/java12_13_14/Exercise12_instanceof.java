package exercises.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018/2019 by Michael Inden 
 */
public class Exercise12_instanceof 
{
	public static void main(String[] args) 
	{	
Object obj ="BITTE ein BIT";

if (obj instanceof String) 
{
	final String str = (String)obj; 
	if (str.contains("BITTE"))
	{
         System.out.println("It contains the magic word!");
    }
}
	}
}
