module timeserver {
	exports com.timeexample.services;
}