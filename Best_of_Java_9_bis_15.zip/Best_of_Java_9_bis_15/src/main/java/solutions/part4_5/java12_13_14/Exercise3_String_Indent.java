package solutions.part4_5.java12_13_14;

/**
 * Beispielprogramm für den Workshop "Best of Java 9, 10 und 11" / das Buch
 * "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 *         Copyright 2017/2018/2019 by Michael Inden
 */
public class Exercise3_String_Indent 
{
	public static void main(String[] args) 
	{
		String originalString = "first_line\nsecond_line\nlast_line";

		// 3a
		System.out.println(originalString);
		System.out.println("-- indented string --");

		String indentedString = originalString.indent(7);
		System.out.println(indentedString);

		System.out.println("-- corrected indented string --");
		String correctIndentedString = indentedString.indent(-3);
		System.out.println(correctIndentedString);

		
		// 3b
		String multipleIndendedString = "class A {\n    public static void main(String[] args) {" + 
                  "\n        System.out.println(\"Hello\"";
		System.out.println(multipleIndendedString);
                  
		System.out.println("-- negatively indended string --");
		String result = multipleIndendedString.indent(-10);
		System.out.println(result);      
	}
}
